import * as React from "react";
import { Image, StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";

const Login = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.loginView}>
      <View style={styles.groupView}>
        <Image
          style={styles.rectangleIcon}
          resizeMode="cover"
          source={require("../assets/rectangle-11.png")}
        />
        <View style={styles.rectangleView} />
        <Text style={styles.usernameText}>Username</Text>
        <View style={styles.rectangleView1} />
        <Text style={styles.passwordText}>Password</Text>
        <Pressable
          style={styles.groupPressable}
          onPress={() => navigation.navigate("Dashboard")}
        >
          <Image
            style={styles.rectangleIcon1}
            resizeMode="cover"
            source={require("../assets/rectangle-41.png")}
          />
          <Text style={styles.masukText}>Masuk</Text>
        </Pressable>
        <Text style={styles.lOGINText}>LOGIN</Text>
      </View>
      <Pressable
        style={styles.belumPunyaAkunDaftar}
        onPress={() => navigation.navigate("Registrasi")}
      >
        <Text style={styles.belumPunyaAkun1}>
          <Text style={styles.belumPunyaAkun}>Belum punya akun?</Text>
        </Text>
        <Text style={styles.daftarText1}>
          <Text style={styles.daftarText}>Daftar</Text>
        </Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleIcon: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 50,
    width: 300,
    height: 300,
  },
  rectangleView: {
    position: "absolute",
    top: 101,
    left: 25,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 250,
    height: 40,
  },
  usernameText: {
    position: "absolute",
    top: 113,
    left: 41,
    fontSize: 14,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rectangleView1: {
    position: "absolute",
    top: 158,
    left: 25,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 250,
    height: 40,
  },
  passwordText: {
    position: "absolute",
    top: 169,
    left: 37,
    fontSize: 14,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rectangleIcon1: {
    position: "absolute",
    top: 0,
    left: -4,
    borderRadius: 25,
    width: 158,
    height: 48,
  },
  masukText: {
    position: "absolute",
    top: 9,
    left: 47,
    fontSize: 18,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupPressable: {
    position: "absolute",
    top: 237,
    left: 75,
    width: 150,
    height: 40,
  },
  lOGINText: {
    position: "absolute",
    top: 17,
    left: 94,
    fontSize: 36,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView: {
    position: "absolute",
    top: 170,
    left: 30,
    width: 300,
    height: 300,
  },
  belumPunyaAkun: {
    fontFamily: "Inter",
  },
  belumPunyaAkun1: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  daftarText: {
    fontWeight: "700",
    fontFamily: "Inter",
  },
  daftarText1: {
    margin: 0,
  },
  belumPunyaAkunDaftar: {
    position: "absolute",
    top: 495,
    left: 116,
    fontSize: 14,
    color: "#000",
    textAlign: "center",
  },
  loginView: {
    position: "relative",
    backgroundColor: "rgba(3, 251, 162, 0.2)",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 640,
    overflow: "hidden",
  },
});

export default Login;
