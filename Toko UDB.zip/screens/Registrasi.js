import * as React from "react";
import { Image, StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";

const Registrasi = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.registrasiView}>
      <View style={styles.groupView}>
        <Image
          style={styles.rectangleIcon}
          resizeMode="cover"
          source={require("../assets/rectangle-1.png")}
        />
        <View style={styles.rectangleView} />
        <Text style={styles.usernameText}>Username</Text>
        <View style={styles.rectangleView1} />
        <Text style={styles.namaText}>Nama</Text>
        <View style={styles.rectangleView2} />
        <Text style={styles.passwordText}>Password</Text>
        <View style={styles.rectangleView3} />
        <Text style={styles.noHPText}>No. HP</Text>
        <View style={styles.rectangleView4} />
        <Text style={styles.emailText}>Email</Text>
        <Pressable
          style={styles.groupPressable}
          onPress={() => navigation.navigate("Login")}
        >
          <Image
            style={styles.rectangleIcon1}
            resizeMode="cover"
            source={require("../assets/rectangle-4.png")}
          />
          <Text style={styles.registrasiText}>Registrasi</Text>
        </Pressable>
        <Pressable
          style={styles.groupPressable1}
          onPress={() => navigation.navigate("Login")}
        >
          <Image
            style={styles.rectangleIcon2}
            resizeMode="cover"
            source={require("../assets/rectangle-4.png")}
          />
          <Text style={styles.batalText}>Batal</Text>
        </Pressable>
        <Text style={styles.registrasiText1}>Registrasi</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleIcon: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 50,
    width: 300,
    height: 450,
  },
  rectangleView: {
    position: "absolute",
    top: 272,
    left: 25,
    borderRadius: 25,
    backgroundColor: "#d9d9d9",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 250,
    height: 40,
  },
  usernameText: {
    position: "absolute",
    top: 284,
    left: 46,
    fontSize: 14,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rectangleView1: {
    position: "absolute",
    top: 86,
    left: 25,
    borderRadius: 25,
    backgroundColor: "#d9d9d9",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 250,
    height: 40,
  },
  namaText: {
    position: "absolute",
    top: 98,
    left: 46,
    fontSize: 14,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rectangleView2: {
    position: "absolute",
    top: 334,
    left: 25,
    borderRadius: 25,
    backgroundColor: "#d9d9d9",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 250,
    height: 40,
  },
  passwordText: {
    position: "absolute",
    top: 346,
    left: 46,
    fontSize: 14,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rectangleView3: {
    position: "absolute",
    top: 210,
    left: 25,
    borderRadius: 25,
    backgroundColor: "#d9d9d9",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 250,
    height: 40,
  },
  noHPText: {
    position: "absolute",
    top: 221,
    left: 46,
    fontSize: 14,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rectangleView4: {
    position: "absolute",
    top: 148,
    left: 25,
    borderRadius: 25,
    backgroundColor: "#d9d9d9",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 250,
    height: 40,
  },
  emailText: {
    position: "absolute",
    top: 159,
    left: 46,
    fontSize: 14,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rectangleIcon1: {
    position: "absolute",
    top: 0,
    left: -4,
    borderRadius: 25,
    width: 118,
    height: 43,
  },
  registrasiText: {
    position: "absolute",
    top: 8,
    left: 17,
    fontSize: 16,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupPressable: {
    position: "absolute",
    top: 396,
    left: 165,
    width: 110,
    height: 35,
  },
  rectangleIcon2: {
    position: "absolute",
    top: 0,
    left: -4,
    borderRadius: 25,
    width: 118,
    height: 43,
  },
  batalText: {
    position: "absolute",
    top: 8,
    left: 35,
    fontSize: 16,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupPressable1: {
    position: "absolute",
    top: 396,
    left: 20,
    width: 110,
    height: 35,
  },
  registrasiText1: {
    position: "absolute",
    top: 13,
    left: 66,
    fontSize: 36,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView: {
    position: "absolute",
    top: 90,
    left: 30,
    width: 300,
    height: 450,
  },
  registrasiView: {
    position: "relative",
    backgroundColor: "rgba(3, 251, 162, 0.2)",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 640,
    overflow: "hidden",
  },
});

export default Registrasi;
