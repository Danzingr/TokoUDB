import * as React from "react";
import {
  StyleSheet,
  View,
  Image,
  Text,
  ScrollView,
  Pressable,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const Dashboard = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.dashboardView}>
      <View style={styles.groupView}>
        <View style={styles.frameView} />
        <Image
          style={styles.lOGO1Icon}
          resizeMode="cover"
          source={require("../assets/logo-11.png")}
        />
        <Text style={styles.ilyasText}>Ilyas</Text>
        <Text style={styles.selamatDatangText}>Selamat Datang</Text>
      </View>
      <View style={styles.groupView1}>
        <View style={styles.rectangleView} />
        <Image
          style={styles.money1Icon}
          resizeMode="cover"
          source={require("../assets/money-11.png")}
        />
        <Text style={styles.rp50000Text}>Rp 50.000</Text>
      </View>
      <ScrollView
        style={styles.frameScrollView}
        horizontal
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.frameScrollViewContent}
      >
        <View style={styles.groupView2}>
          <View style={styles.rectangleView1} />
          <Image
            style={styles.transactionHistory1Icon}
            resizeMode="cover"
            source={require("../assets/transactionhistory-1.png")}
          />
          <Text style={styles.transaksiText}>Transaksi</Text>
        </View>
        <View style={[styles.groupView3, styles.ml15]}>
          <View style={styles.rectangleView2} />
          <Text style={styles.favoriteText}>Favorite</Text>
          <Image
            style={styles.addToFavorites1Icon}
            resizeMode="cover"
            source={require("../assets/addtofavorites-1.png")}
          />
        </View>
        <View style={[styles.groupView4, styles.ml15]}>
          <View style={styles.rectangleView3} />
          <Image
            style={styles.officialStore1Icon}
            resizeMode="cover"
            source={require("../assets/officialstore-1.png")}
          />
          <Text style={styles.officialText}>Official</Text>
        </View>
        <View style={[styles.groupView5, styles.ml15]}>
          <View style={styles.rectangleView4} />
          <Text style={styles.inboxText}>Inbox</Text>
          <Image
            style={styles.inbox1Icon}
            resizeMode="cover"
            source={require("../assets/inbox-1.png")}
          />
        </View>
      </ScrollView>
      <View style={styles.frameView1}>
        <Image
          style={styles.homeIconSilhouette1}
          resizeMode="cover"
          source={require("../assets/homeiconsilhouette-1.png")}
        />
        <Pressable
          style={[styles.localGroceryStorePressable, styles.ml60]}
          onPress={() => navigation.navigate("Keranjang")}
        >
          <Text style={styles.localGroceryStoreText}>local_grocery_store</Text>
        </Pressable>
        <Pressable
          style={[styles.inboxPressable, styles.ml60]}
          onPress={() => navigation.navigate("Inbox")}
        >
          <Text style={styles.inboxText1}>inbox</Text>
        </Pressable>
        <Pressable
          style={[styles.user1Pressable, styles.ml60]}
          onPress={() => navigation.navigate("Profil")}
        >
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/user-1.png")}
          />
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  ml15: {
    marginLeft: 15,
  },
  frameScrollViewContent: {
    alignItems: "center",
    justifyContent: "flex-start",
    flexDirection: "row",
  },
  ml60: {
    marginLeft: 60,
  },
  frameView: {
    position: "absolute",
    top: 0,
    left: 0,
    borderBottomRightRadius: 25,
    borderBottomLeftRadius: 25,
    backgroundColor: "#fff",
    width: 360,
    height: 149,
    overflow: "hidden",
  },
  lOGO1Icon: {
    position: "absolute",
    top: 4,
    left: 232,
    width: 103.68,
    height: 140,
  },
  ilyasText: {
    position: "absolute",
    top: 45,
    left: 21,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  selamatDatangText: {
    position: "absolute",
    top: 16,
    left: 21,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 360,
    height: 149,
  },
  rectangleView: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 30,
    backgroundColor: "#59c063",
    width: 300,
    height: 75,
  },
  money1Icon: {
    position: "absolute",
    top: 15,
    left: 57,
    width: 50,
    height: 50,
  },
  rp50000Text: {
    position: "absolute",
    top: 28,
    left: 133,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#fff",
    textAlign: "left",
  },
  groupView1: {
    position: "absolute",
    top: 109,
    left: 30,
    width: 300,
    height: 75,
  },
  rectangleView1: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 20,
    backgroundColor: "#59c063",
    width: 125,
    height: 125,
  },
  transactionHistory1Icon: {
    position: "absolute",
    top: 12,
    left: 23,
    width: 80,
    height: 80,
  },
  transaksiText: {
    position: "absolute",
    top: 96,
    left: 23,
    fontSize: 16,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#fff",
    textAlign: "left",
  },
  groupView2: {
    position: "relative",
    width: 125,
    height: 125,
    flexShrink: 0,
  },
  rectangleView2: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 20,
    backgroundColor: "#59c063",
    width: 125,
    height: 125,
  },
  favoriteText: {
    position: "absolute",
    top: 96,
    left: 31,
    fontSize: 16,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#fff",
    textAlign: "left",
  },
  addToFavorites1Icon: {
    position: "absolute",
    top: 12,
    left: 23,
    width: 80,
    height: 80,
  },
  groupView3: {
    position: "relative",
    width: 125,
    height: 125,
    flexShrink: 0,
  },
  rectangleView3: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 20,
    backgroundColor: "#59c063",
    width: 125,
    height: 125,
  },
  officialStore1Icon: {
    position: "absolute",
    top: 13,
    left: 23,
    width: 80,
    height: 80,
  },
  officialText: {
    position: "absolute",
    top: 97,
    left: 33,
    fontSize: 16,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#fff",
    textAlign: "left",
  },
  groupView4: {
    position: "relative",
    width: 125,
    height: 125,
    flexShrink: 0,
  },
  rectangleView4: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 20,
    backgroundColor: "#59c063",
    width: 125,
    height: 125,
  },
  inboxText: {
    position: "absolute",
    top: 97,
    left: 41,
    fontSize: 16,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#fff",
    textAlign: "left",
  },
  inbox1Icon: {
    position: "absolute",
    top: 13,
    left: 23,
    width: 80,
    height: 80,
  },
  groupView5: {
    position: "relative",
    width: 125,
    height: 125,
    flexShrink: 0,
  },
  frameScrollView: {
    position: "absolute",
    top: 195,
    left: 10,
    width: "100%",
  },
  homeIconSilhouette1: {
    position: "relative",
    width: 30,
    height: 30,
    flexShrink: 0,
  },
  localGroceryStoreText: {
    fontSize: 30,
    fontFamily: "Material Icons",
    color: "#00ab66",
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 30,
    height: 30,
  },
  localGroceryStorePressable: {
    position: "relative",
  },
  inboxText1: {
    fontSize: 30,
    fontFamily: "Material Icons",
    color: "#00ab66",
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 30,
    height: 30,
  },
  inboxPressable: {
    position: "relative",
  },
  icon: {
    width: "100%",
    height: "100%",
    flexShrink: 0,
  },
  user1Pressable: {
    position: "relative",
    width: 30,
    height: 30,
  },
  frameView1: {
    position: "absolute",
    top: 590,
    left: 0,
    backgroundColor: "#fff",
    width: 360,
    flexDirection: "row",
    paddingHorizontal: 22,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  dashboardView: {
    position: "relative",
    backgroundColor: "rgba(3, 251, 162, 0.2)",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 640,
    overflow: "hidden",
  },
});

export default Dashboard;
