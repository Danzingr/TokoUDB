import * as React from "react";
import { Text, StyleSheet, View, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";

const Inbox = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.inboxView}>
      <View style={styles.frameView}>
        <Text style={styles.insertEmoticonText}>insert_emoticon</Text>
        <View style={[styles.groupView, styles.ml15]}>
          <View style={styles.rectangleView} />
          <Text style={styles.attachFileText}>attach_file</Text>
          <Text style={styles.tulisPesan}>Tulis pesan ..</Text>
        </View>
        <View style={[styles.groupView1, styles.ml15]}>
          <Image
            style={styles.ellipseIcon}
            resizeMode="cover"
            source={require("../assets/ellipse-1.png")}
          />
          <Text style={styles.sendText}>send</Text>
        </View>
      </View>
      <View style={styles.groupView2}>
        <View style={styles.rectangleView1} />
        <Text style={styles.batasMaksimalOrderPukul16}>
          <Text style={styles.batasMaksimalOrder}>
            Batas maksimal order pukul 16.00 WIB dikirim hari yang sama.
          </Text>
          <Text style={styles.orderDiatasPukul}>
            Order diatas pukul 16.00 WIB akan dikirim hari besoknya.
          </Text>
          <Text style={styles.blankLineText}> </Text>
          <Text style={styles.terimakasihText}>Terimakasih</Text>
        </Text>
      </View>
      <View style={styles.groupView3}>
        <View style={styles.rectangleView2} />
        <Text
          style={styles.bisaDikirimHariIni}
        >{`Bisa dikirim hari ini? `}</Text>
      </View>
      <View style={styles.groupView4}>
        <View style={styles.rectangleView3} />
        <Text style={styles.selamatDatangDiUDBStore}>
          <Text style={styles.selamatDatangDi}>
            Selamat datang di UDB Store ^_^
          </Text>
          <Text style={styles.blankLineText1}> </Text>
          <Text style={styles.adaYangBisa}>Ada yang bisa kami bantu?</Text>
        </Text>
      </View>
      <View style={styles.groupView5}>
        <View style={styles.rectangleView4} />
        <Pressable
          style={styles.groupPressable}
          onPress={() => navigation.goBack()}
        >
          <View style={styles.rectangleView5} />
          <Image
            style={styles.arrowIcon}
            resizeMode="cover"
            source={require("../assets/arrow-1.png")}
          />
        </Pressable>
        <Text style={styles.inboxText}>Inbox</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  ml15: {
    marginLeft: 15,
  },
  insertEmoticonText: {
    position: "relative",
    fontSize: 30,
    fontFamily: "Material Icons",
    color: "#00ab66",
    textAlign: "center",
  },
  rectangleView: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 25,
    backgroundColor: "#d9d9d9",
    width: 243,
    height: 30,
  },
  attachFileText: {
    position: "absolute",
    top: 5,
    left: 212,
    fontSize: 20,
    fontFamily: "Material Icons",
    color: "#00ab66",
    textAlign: "center",
  },
  tulisPesan: {
    position: "absolute",
    top: 8,
    left: 11.5,
    fontSize: 11,
    fontFamily: "Inter",
    color: "rgba(0, 0, 0, 0.62)",
    textAlign: "left",
  },
  groupView: {
    position: "relative",
    width: 243,
    height: 30,
    flexShrink: 0,
  },
  ellipseIcon: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 30,
    height: 30,
  },
  sendText: {
    position: "absolute",
    top: 7,
    left: 8,
    fontSize: 17,
    fontFamily: "Material Icons",
    color: "#fff",
    textAlign: "center",
  },
  groupView1: {
    position: "relative",
    width: 30,
    height: 30,
    flexShrink: 0,
  },
  frameView: {
    position: "absolute",
    top: 592,
    left: 0,
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: -4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 360,
    flexDirection: "row",
    paddingHorizontal: 14,
    paddingVertical: 9,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  rectangleView1: {
    position: "absolute",
    top: 0,
    left: 0,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    borderBottomRightRadius: 10,
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.1)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    width: 258,
    height: 92,
  },
  batasMaksimalOrder: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  orderDiatasPukul: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  blankLineText: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  terimakasihText: {
    margin: 0,
  },
  batasMaksimalOrderPukul16: {
    position: "absolute",
    top: 0,
    left: 6,
    fontSize: 12,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
    width: 250,
    height: 92,
  },
  groupView2: {
    position: "absolute",
    top: 484,
    left: 10,
    width: 258,
    height: 92,
  },
  rectangleView2: {
    position: "absolute",
    top: 0,
    left: 0,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    borderBottomLeftRadius: 10,
    backgroundColor: "rgba(0, 171, 102, 0.15)",
    shadowColor: "rgba(0, 0, 0, 0.1)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    width: 122,
    height: 25,
  },
  bisaDikirimHariIni: {
    position: "absolute",
    top: 4,
    left: 5,
    fontSize: 12,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
    width: 112,
    height: 13,
  },
  groupView3: {
    position: "absolute",
    top: 443,
    left: 230,
    shadowColor: "rgba(0, 0, 0, 0.1)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    width: 122,
    height: 25,
  },
  rectangleView3: {
    position: "absolute",
    top: 0,
    left: 0,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    borderBottomRightRadius: 10,
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.1)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    width: 258,
    height: 50,
  },
  selamatDatangDi: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  blankLineText1: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  adaYangBisa: {
    margin: 0,
  },
  selamatDatangDiUDBStore: {
    position: "absolute",
    top: 2,
    left: 6,
    fontSize: 12,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
    width: 186,
    height: 45,
  },
  groupView4: {
    position: "absolute",
    top: 377,
    left: 10,
    width: 258,
    height: 50,
  },
  rectangleView4: {
    position: "absolute",
    top: 0,
    left: 0,
    backgroundColor: "#fff",
    width: 360,
    height: 50,
  },
  rectangleView5: {
    position: "absolute",
    top: 0,
    left: 0,
    backgroundColor: "rgba(255, 255, 255, 0)",
    width: 25,
    height: 25,
  },
  arrowIcon: {
    position: "absolute",
    top: 1.95,
    left: 1.5,
    width: 21.5,
    height: 22.09,
  },
  groupPressable: {
    position: "absolute",
    top: 12,
    left: 13,
    width: 25,
    height: 25,
  },
  inboxText: {
    position: "absolute",
    top: 13,
    left: 51,
    fontSize: 20,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView5: {
    position: "absolute",
    top: 0,
    left: 0,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 360,
    height: 50,
  },
  inboxView: {
    position: "relative",
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 640,
    overflow: "hidden",
  },
});

export default Inbox;
