import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";

const SplashScreen = () => {
  return (
    <View style={styles.splashScreenView}>
      <Image
        style={styles.lOGO1Icon}
        resizeMode="cover"
        source={require("../assets/logo-1.png")}
      />
      <Text style={styles.tOKOUDBText}>TOKO UDB</Text>
      <Text style={styles.ver10Text}>Ver 1.0</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  lOGO1Icon: {
    position: "absolute",
    top: 177,
    left: 76,
    width: 209,
    height: 286,
  },
  tOKOUDBText: {
    position: "absolute",
    top: 108,
    left: 76,
    fontSize: 40,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#f5f5f5",
    textAlign: "left",
  },
  ver10Text: {
    position: "absolute",
    top: 509,
    left: 158,
    fontSize: 14,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  splashScreenView: {
    position: "relative",
    backgroundColor: "rgba(3, 251, 162, 0.2)",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 640,
    overflow: "hidden",
  },
});

export default SplashScreen;
