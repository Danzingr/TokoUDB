import * as React from "react";
import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";

const Transaksi = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.transaksiView}>
      <View style={styles.groupView1}>
        <View style={styles.rectangleView} />
        <Text style={styles.rp218000Text}>Rp 218.000</Text>
        <Text style={styles.totalTagihanText}>Total Tagihan</Text>
        <View style={styles.groupView}>
          <View style={styles.rectangleView1} />
          <Text style={styles.bayarText}>Bayar</Text>
        </View>
      </View>
      <View style={styles.groupView2}>
        <View style={styles.rectangleView2} />
        <Text style={styles.rp0Text}>Rp0</Text>
        <Text style={styles.rp18000Text}>Rp18.000</Text>
        <Text style={styles.rp200000Text}>Rp200.000</Text>
        <Text style={styles.diskonText}>Diskon</Text>
        <Text style={styles.ongkosKirimText}>Ongkos Kirim</Text>
        <Text style={styles.totalHargaText}>Total Harga</Text>
        <Text style={styles.rincianPembayaranText}>Rincian Pembayaran</Text>
      </View>
      <View style={styles.groupView4}>
        <View style={styles.rectangleView3} />
        <Text style={styles.keyboardArrowRightText}>keyboard_arrow_right</Text>
        <View style={styles.groupView3}>
          <Text style={styles.estimasiTiba35Hari}>
            Estimasi tiba 3 - 5 hari
          </Text>
          <Text style={styles.jNERegRp18000}>JNE Reg (Rp18.000)</Text>
        </View>
        <Text style={styles.detailPengirimanText}>Detail Pengiriman</Text>
      </View>
      <View style={styles.groupView5}>
        <View style={styles.rectangleView4} />
        <Image
          style={styles.k120Gallery01New1Icon}
          resizeMode="cover"
          source={require("../assets/k120gallery01new-1.png")}
        />
        <Text style={styles.xRp200000}>1 x Rp 200.000</Text>
        <Text style={styles.keyboardLogitechText}>Keyboard Logitech</Text>
        <Text style={styles.detailProdukText}>Detail Produk</Text>
      </View>
      <View style={styles.groupView6}>
        <View style={styles.rectangleView5} />
        <Text style={styles.ilyasRixqiMartuti085742505}>
          <Text style={styles.ilyasRixqiMartuti}>
            Ilyas Rixqi Martuti (085742505010)
          </Text>
          <Text style={styles.bibisLuhurRt}>
            Bibis Luhur Rt 07/21 Nusukan, Banjarsari, Kota Surakarta
          </Text>
        </Text>
        <Text style={styles.alamatPengirimanText}>Alamat Pengiriman</Text>
      </View>
      <View style={styles.groupView7}>
        <View style={styles.rectangleView6} />
        <Pressable
          style={styles.groupPressable}
          onPress={() => navigation.goBack()}
        >
          <View style={styles.rectangleView7} />
          <Image
            style={styles.arrowIcon}
            resizeMode="cover"
            source={require("../assets/arrow-1.png")}
          />
        </Pressable>
        <Text style={styles.transaksiText}>Transaksi</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleView: {
    position: "absolute",
    top: 0,
    left: 0,
    backgroundColor: "#fff",
    width: 360,
    height: 66,
  },
  rp218000Text: {
    position: "absolute",
    top: 33,
    left: 20,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  totalTagihanText: {
    position: "absolute",
    top: 11,
    left: 20,
    fontSize: 16,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rectangleView1: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 15,
    backgroundColor: "#00ab66",
    width: 101,
    height: 40,
  },
  bayarText: {
    position: "absolute",
    top: 8,
    left: 23,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#fff",
    textAlign: "left",
  },
  groupView: {
    position: "absolute",
    top: 13,
    left: 244,
    width: 101,
    height: 40,
  },
  groupView1: {
    position: "absolute",
    top: 574,
    left: 0,
    width: 360,
    height: 66,
  },
  rectangleView2: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#fff",
    width: 340,
    height: 82,
  },
  rp0Text: {
    position: "absolute",
    top: 59,
    left: 307,
    fontSize: 12,
    fontWeight: "300",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rp18000Text: {
    position: "absolute",
    top: 44,
    left: 278,
    fontSize: 12,
    fontWeight: "300",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rp200000Text: {
    position: "absolute",
    top: 29,
    left: 268,
    fontSize: 12,
    fontWeight: "300",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  diskonText: {
    position: "absolute",
    top: 59,
    left: 7,
    fontSize: 12,
    fontWeight: "300",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  ongkosKirimText: {
    position: "absolute",
    top: 44,
    left: 7,
    fontSize: 12,
    fontWeight: "300",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  totalHargaText: {
    position: "absolute",
    top: 29,
    left: 6,
    fontSize: 12,
    fontWeight: "300",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rincianPembayaranText: {
    position: "absolute",
    top: 7,
    left: 6,
    fontSize: 12,
    fontWeight: "600",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView2: {
    position: "absolute",
    top: 277,
    left: 10,
    width: 340,
    height: 82,
  },
  rectangleView3: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#fff",
    width: 340,
    height: 64,
  },
  keyboardArrowRightText: {
    position: "absolute",
    top: 29,
    left: 310,
    fontSize: 20,
    fontFamily: "Material Icons",
    color: "#000",
    textAlign: "center",
  },
  estimasiTiba35Hari: {
    position: "absolute",
    top: 15,
    left: 0,
    fontSize: 11,
    fontWeight: "200",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  jNERegRp18000: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 12,
    fontWeight: "500",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView3: {
    position: "absolute",
    top: 24,
    left: 6,
    width: 115,
    height: 28,
  },
  detailPengirimanText: {
    position: "absolute",
    top: 2,
    left: 6,
    fontSize: 12,
    fontWeight: "600",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView4: {
    position: "absolute",
    top: 203,
    left: 10,
    width: 340,
    height: 64,
  },
  rectangleView4: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#fff",
    width: 340,
    height: 64,
  },
  k120Gallery01New1Icon: {
    position: "absolute",
    top: 22,
    left: 7,
    width: 75,
    height: 37.5,
  },
  xRp200000: {
    position: "absolute",
    top: 37,
    left: 89,
    fontSize: 12,
    fontWeight: "500",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  keyboardLogitechText: {
    position: "absolute",
    top: 22,
    left: 89,
    fontSize: 12,
    fontWeight: "600",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  detailProdukText: {
    position: "absolute",
    top: 2,
    left: 6,
    fontSize: 12,
    fontWeight: "600",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView5: {
    position: "absolute",
    top: 129,
    left: 10,
    width: 340,
    height: 64,
  },
  rectangleView5: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#fff",
    width: 340,
    height: 59,
  },
  ilyasRixqiMartuti: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  bibisLuhurRt: {
    margin: 0,
  },
  ilyasRixqiMartuti085742505: {
    position: "absolute",
    top: 18,
    left: 6,
    fontSize: 12,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  alamatPengirimanText: {
    position: "absolute",
    top: 0,
    left: 6,
    fontSize: 12,
    fontWeight: "600",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView6: {
    position: "absolute",
    top: 60,
    left: 10,
    width: 340,
    height: 59,
  },
  rectangleView6: {
    position: "absolute",
    top: 0,
    left: 0,
    backgroundColor: "#fff",
    width: 360,
    height: 50,
  },
  rectangleView7: {
    position: "absolute",
    top: 0,
    left: 0,
    backgroundColor: "rgba(255, 255, 255, 0)",
    width: 26,
    height: 26,
  },
  arrowIcon: {
    position: "absolute",
    top: 2.95,
    left: 2.5,
    width: 21.5,
    height: 22.09,
  },
  groupPressable: {
    position: "absolute",
    top: 11,
    left: 16,
    width: 26,
    height: 26,
  },
  transaksiText: {
    position: "absolute",
    top: 13,
    left: 51,
    fontSize: 20,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView7: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 360,
    height: 50,
  },
  transaksiView: {
    position: "relative",
    backgroundColor: "rgba(3, 251, 162, 0.2)",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 640,
    overflow: "hidden",
  },
});

export default Transaksi;
