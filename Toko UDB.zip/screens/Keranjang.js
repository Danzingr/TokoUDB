import * as React from "react";
import {
  ScrollView,
  StyleSheet,
  View,
  Image,
  Text,
  Pressable,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const Keranjang = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.keranjangView}>
      <ScrollView
        style={styles.frameScrollView}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.frameScrollViewContent}
      >
        <View style={styles.groupView}>
          <View style={styles.rectangleView} />
          <Image
            style={styles.logitechM220Silent1Icon}
            resizeMode="cover"
            source={require("../assets/1615621440747logitechm220silent-1.png")}
          />
          <Text style={styles.mouseLogitechText}>Mouse Logitech</Text>
          <Text style={styles.rp100000Text}>Rp 100.000</Text>
          <Image
            style={styles.bin1Icon}
            resizeMode="cover"
            source={require("../assets/bin-1.png")}
          />
          <Image
            style={styles.vectorIcon}
            resizeMode="cover"
            source={require("../assets/vector.png")}
          />
          <Image
            style={styles.vectorIcon1}
            resizeMode="cover"
            source={require("../assets/vector1.png")}
          />
          <Text style={styles.text}>1</Text>
        </View>
        <View style={[styles.groupView1, styles.mt15]}>
          <View style={styles.rectangleView1} />
          <Text style={styles.keyboardLogitechText}>Keyboard Logitech</Text>
          <Text style={styles.rp200000Text}>Rp 200.000</Text>
          <Image
            style={styles.bin1Icon1}
            resizeMode="cover"
            source={require("../assets/bin-1.png")}
          />
          <Image
            style={styles.vectorIcon2}
            resizeMode="cover"
            source={require("../assets/vector.png")}
          />
          <Image
            style={styles.vectorIcon3}
            resizeMode="cover"
            source={require("../assets/vector1.png")}
          />
          <Text style={styles.text1}>1</Text>
          <Image
            style={styles.k120Gallery01New1Icon}
            resizeMode="cover"
            source={require("../assets/k120gallery01new-1.png")}
          />
        </View>
        <View style={[styles.groupView2, styles.mt15]}>
          <View style={styles.rectangleView2} />
          <Image
            style={styles.logitechM220Silent1Icon1}
            resizeMode="cover"
            source={require("../assets/1615621440747logitechm220silent-1.png")}
          />
          <Text style={styles.mouseLogitechText1}>Mouse Logitech</Text>
          <Text style={styles.rp100000Text1}>Rp 100.000</Text>
          <Image
            style={styles.bin1Icon2}
            resizeMode="cover"
            source={require("../assets/bin-1.png")}
          />
          <Image
            style={styles.vectorIcon4}
            resizeMode="cover"
            source={require("../assets/vector.png")}
          />
          <Image
            style={styles.vectorIcon5}
            resizeMode="cover"
            source={require("../assets/vector1.png")}
          />
          <Text style={styles.text2}>1</Text>
        </View>
        <View style={[styles.groupView3, styles.mt15]}>
          <View style={styles.rectangleView3} />
          <Text style={styles.keyboardLogitechText1}>Keyboard Logitech</Text>
          <Text style={styles.rp200000Text1}>Rp 200.000</Text>
          <Image
            style={styles.bin1Icon3}
            resizeMode="cover"
            source={require("../assets/bin-1.png")}
          />
          <Image
            style={styles.vectorIcon6}
            resizeMode="cover"
            source={require("../assets/vector.png")}
          />
          <Image
            style={styles.vectorIcon7}
            resizeMode="cover"
            source={require("../assets/vector1.png")}
          />
          <Text style={styles.text3}>1</Text>
          <Image
            style={styles.k120Gallery01New1Icon1}
            resizeMode="cover"
            source={require("../assets/k120gallery01new-1.png")}
          />
        </View>
        <View style={[styles.groupView4, styles.mt15]}>
          <View style={styles.rectangleView4} />
          <Image
            style={styles.logitechM220Silent1Icon2}
            resizeMode="cover"
            source={require("../assets/1615621440747logitechm220silent-1.png")}
          />
          <Text style={styles.mouseLogitechText2}>Mouse Logitech</Text>
          <Text style={styles.rp100000Text2}>Rp 100.000</Text>
          <Image
            style={styles.bin1Icon4}
            resizeMode="cover"
            source={require("../assets/bin-1.png")}
          />
          <Image
            style={styles.vectorIcon8}
            resizeMode="cover"
            source={require("../assets/vector.png")}
          />
          <Image
            style={styles.vectorIcon9}
            resizeMode="cover"
            source={require("../assets/vector1.png")}
          />
          <Text style={styles.text4}>1</Text>
        </View>
        <View style={[styles.groupView5, styles.mt15]}>
          <View style={styles.rectangleView5} />
          <Text style={styles.keyboardLogitechText2}>Keyboard Logitech</Text>
          <Text style={styles.rp200000Text2}>Rp 200.000</Text>
          <Image
            style={styles.bin1Icon5}
            resizeMode="cover"
            source={require("../assets/bin-15.png")}
          />
          <Image
            style={styles.vectorIcon10}
            resizeMode="cover"
            source={require("../assets/vector10.png")}
          />
          <Image
            style={styles.vectorIcon11}
            resizeMode="cover"
            source={require("../assets/vector10.png")}
          />
          <Text style={styles.text5}>1</Text>
          <Image
            style={styles.k120Gallery01New1Icon2}
            resizeMode="cover"
            source={require("../assets/k120gallery01new-13.png")}
          />
        </View>
      </ScrollView>
      <View style={styles.groupView6}>
        <View style={styles.rectangleView6} />
        <Text style={styles.totalHargaText}>Total Harga</Text>
        <Text style={styles.rp200000Text3}>Rp 200.000</Text>
        <Pressable
          style={styles.groupPressable}
          onPress={() => navigation.navigate("Transaksi")}
        >
          <View style={styles.rectangleView7} />
          <Text style={styles.beliText}>Beli</Text>
        </Pressable>
      </View>
      <View style={styles.groupView7}>
        <View style={styles.rectangleView8} />
        <Pressable
          style={styles.groupPressable1}
          onPress={() => navigation.goBack()}
        >
          <View style={styles.rectangleView9} />
          <Image
            style={styles.arrowIcon}
            resizeMode="cover"
            source={require("../assets/arrow-1.png")}
          />
        </Pressable>
        <Text style={styles.keranjangText}>Keranjang</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  mt15: {
    marginTop: 15,
  },
  frameScrollViewContent: {
    alignItems: "center",
    justifyContent: "flex-start",
    flexDirection: "column",
  },
  rectangleView: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.5)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 320,
    height: 100,
  },
  logitechM220Silent1Icon: {
    position: "absolute",
    top: 13,
    left: 10,
    width: 75,
    height: 75,
  },
  mouseLogitechText: {
    position: "absolute",
    top: 11,
    left: 85,
    fontSize: 16,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rp100000Text: {
    position: "absolute",
    top: 33,
    left: 85,
    fontSize: 15,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  bin1Icon: {
    position: "absolute",
    top: 63,
    left: 286,
    width: 25,
    height: 25,
  },
  vectorIcon: {
    position: "absolute",
    height: "24.22%",
    width: "7.57%",
    top: "63%",
    right: "35.56%",
    bottom: "12.78%",
    left: "56.88%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  vectorIcon1: {
    position: "absolute",
    height: "24.22%",
    width: "7.57%",
    top: "63%",
    right: "17.43%",
    bottom: "12.78%",
    left: "75%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  text: {
    position: "absolute",
    top: 63,
    left: 219,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView: {
    position: "relative",
    width: 320,
    height: 100,
    flexShrink: 0,
  },
  rectangleView1: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.5)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 320,
    height: 100,
  },
  keyboardLogitechText: {
    position: "absolute",
    top: 11,
    left: 85,
    fontSize: 16,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rp200000Text: {
    position: "absolute",
    top: 33,
    left: 85,
    fontSize: 15,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  bin1Icon1: {
    position: "absolute",
    top: 63,
    left: 286,
    width: 25,
    height: 25,
  },
  vectorIcon2: {
    position: "absolute",
    height: "24.22%",
    width: "7.57%",
    top: "63%",
    right: "35.56%",
    bottom: "12.78%",
    left: "56.88%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  vectorIcon3: {
    position: "absolute",
    height: "24.22%",
    width: "7.57%",
    top: "63%",
    right: "17.43%",
    bottom: "12.78%",
    left: "75%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  text1: {
    position: "absolute",
    top: 63,
    left: 219,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  k120Gallery01New1Icon: {
    position: "absolute",
    top: 31,
    left: 10,
    width: 75,
    height: 37.5,
  },
  groupView1: {
    position: "relative",
    width: 320,
    height: 100,
    flexShrink: 0,
  },
  rectangleView2: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.5)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 320,
    height: 100,
  },
  logitechM220Silent1Icon1: {
    position: "absolute",
    top: 13,
    left: 10,
    width: 75,
    height: 75,
  },
  mouseLogitechText1: {
    position: "absolute",
    top: 11,
    left: 85,
    fontSize: 16,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rp100000Text1: {
    position: "absolute",
    top: 33,
    left: 85,
    fontSize: 15,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  bin1Icon2: {
    position: "absolute",
    top: 63,
    left: 286,
    width: 25,
    height: 25,
  },
  vectorIcon4: {
    position: "absolute",
    height: "24.22%",
    width: "7.57%",
    top: "63%",
    right: "35.56%",
    bottom: "12.78%",
    left: "56.88%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  vectorIcon5: {
    position: "absolute",
    height: "24.22%",
    width: "7.57%",
    top: "63%",
    right: "17.43%",
    bottom: "12.78%",
    left: "75%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  text2: {
    position: "absolute",
    top: 63,
    left: 219,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView2: {
    position: "relative",
    width: 320,
    height: 100,
    flexShrink: 0,
  },
  rectangleView3: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.5)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 320,
    height: 100,
  },
  keyboardLogitechText1: {
    position: "absolute",
    top: 11,
    left: 85,
    fontSize: 16,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rp200000Text1: {
    position: "absolute",
    top: 33,
    left: 85,
    fontSize: 15,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  bin1Icon3: {
    position: "absolute",
    top: 63,
    left: 286,
    width: 25,
    height: 25,
  },
  vectorIcon6: {
    position: "absolute",
    height: "24.22%",
    width: "7.57%",
    top: "63%",
    right: "35.56%",
    bottom: "12.78%",
    left: "56.88%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  vectorIcon7: {
    position: "absolute",
    height: "24.22%",
    width: "7.57%",
    top: "63%",
    right: "17.43%",
    bottom: "12.78%",
    left: "75%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  text3: {
    position: "absolute",
    top: 63,
    left: 219,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  k120Gallery01New1Icon1: {
    position: "absolute",
    top: 31,
    left: 10,
    width: 75,
    height: 37.5,
  },
  groupView3: {
    position: "relative",
    width: 320,
    height: 100,
    flexShrink: 0,
  },
  rectangleView4: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.5)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 320,
    height: 100,
  },
  logitechM220Silent1Icon2: {
    position: "absolute",
    top: 13,
    left: 10,
    width: 75,
    height: 75,
  },
  mouseLogitechText2: {
    position: "absolute",
    top: 11,
    left: 85,
    fontSize: 16,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rp100000Text2: {
    position: "absolute",
    top: 33,
    left: 85,
    fontSize: 15,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  bin1Icon4: {
    position: "absolute",
    top: 63,
    left: 286,
    width: 25,
    height: 25,
  },
  vectorIcon8: {
    position: "absolute",
    height: "24.22%",
    width: "7.57%",
    top: "63%",
    right: "35.56%",
    bottom: "12.78%",
    left: "56.88%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  vectorIcon9: {
    position: "absolute",
    height: "24.22%",
    width: "7.57%",
    top: "63%",
    right: "17.43%",
    bottom: "12.78%",
    left: "75%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  text4: {
    position: "absolute",
    top: 63,
    left: 219,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView4: {
    position: "relative",
    width: 320,
    height: 100,
    flexShrink: 0,
  },
  rectangleView5: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.5)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 320,
    height: 100,
  },
  keyboardLogitechText2: {
    position: "absolute",
    top: 11,
    left: 85,
    fontSize: 16,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rp200000Text2: {
    position: "absolute",
    top: 33,
    left: 85,
    fontSize: 15,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  bin1Icon5: {
    position: "absolute",
    top: 638,
    left: 306,
    width: 25,
    height: 25,
  },
  vectorIcon10: {
    position: "absolute",
    height: "24.22%",
    width: "7.57%",
    top: "638%",
    right: "29.31%",
    bottom: "-562.22%",
    left: "63.13%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  vectorIcon11: {
    position: "absolute",
    height: "24.22%",
    width: "7.57%",
    top: "638%",
    right: "11.18%",
    bottom: "-562.22%",
    left: "81.25%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  text5: {
    position: "absolute",
    top: 63,
    left: 219,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  k120Gallery01New1Icon2: {
    position: "absolute",
    top: 606,
    left: 30,
    width: 75,
    height: 37.5,
  },
  groupView5: {
    position: "relative",
    width: 320,
    height: 100,
    flexShrink: 0,
  },
  frameScrollView: {
    position: "absolute",
    top: 64,
    left: 0,
    width: 360,
    flex: 1,
    maxWidth: 360,
  },
  rectangleView6: {
    position: "absolute",
    top: 0,
    left: 0,
    backgroundColor: "#fff",
    width: 360,
    height: 66,
  },
  totalHargaText: {
    position: "absolute",
    top: 11,
    left: 20,
    fontSize: 16,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rp200000Text3: {
    position: "absolute",
    top: 33,
    left: 20,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  rectangleView7: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 15,
    backgroundColor: "#00ab66",
    width: 101,
    height: 40,
  },
  beliText: {
    position: "absolute",
    top: 8,
    left: 32,
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#fff",
    textAlign: "left",
  },
  groupPressable: {
    position: "absolute",
    top: 13,
    left: 244,
    width: 101,
    height: 40,
  },
  groupView6: {
    position: "absolute",
    top: 574,
    left: 0,
    width: 360,
    height: 66,
  },
  rectangleView8: {
    position: "absolute",
    top: 0,
    left: 0,
    backgroundColor: "#fff",
    width: 360,
    height: 50,
  },
  rectangleView9: {
    position: "absolute",
    top: 0,
    left: 0,
    backgroundColor: "rgba(255, 255, 255, 0)",
    width: 26,
    height: 26,
  },
  arrowIcon: {
    position: "absolute",
    top: 2.95,
    left: 2.5,
    width: 21.5,
    height: 22.09,
  },
  groupPressable1: {
    position: "absolute",
    top: 11,
    left: 16,
    width: 26,
    height: 26,
  },
  keranjangText: {
    position: "absolute",
    top: 13,
    left: 51,
    fontSize: 20,
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  groupView7: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 360,
    height: 50,
  },
  keranjangView: {
    position: "relative",
    backgroundColor: "rgba(3, 251, 162, 0.2)",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 640,
    overflow: "hidden",
  },
});

export default Keranjang;
