import * as React from "react";
import { Image, StyleSheet, Pressable, Text, View } from "react-native";
import { useNavigation } from "@react-navigation/native";

const Profil = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.profilView}>
      <View style={styles.frameView}>
        <Pressable
          style={styles.homeIconSilhouette1Pressable}
          onPress={() => navigation.navigate("Dashboard")}
        >
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/homeiconsilhouette-1.png")}
          />
        </Pressable>
        <Pressable
          style={[styles.localGroceryStorePressable, styles.ml60]}
          onPress={() => navigation.navigate("Keranjang")}
        >
          <Text style={styles.localGroceryStoreText}>local_grocery_store</Text>
        </Pressable>
        <Pressable
          style={[styles.inboxPressable, styles.ml60]}
          onPress={() => navigation.navigate("Inbox")}
        >
          <Text style={styles.inboxText}>inbox</Text>
        </Pressable>
        <Image
          style={[styles.user1Icon, styles.ml60]}
          resizeMode="cover"
          source={require("../assets/user-1.png")}
        />
      </View>
      <View style={styles.groupView2}>
        <View style={styles.frameView1} />
        <View style={styles.groupView}>
          <Image
            style={styles.money1Icon}
            resizeMode="cover"
            source={require("../assets/money-1.png")}
          />
          <Text style={styles.rp50000Text}>Rp 50.000</Text>
        </View>
        <Text style={styles.ilyasRixqiMartuti}>Ilyas Rixqi Martuti</Text>
        <View style={styles.groupView1}>
          <Image
            style={styles.ellipseIcon}
            resizeMode="cover"
            source={require("../assets/ellipse-2.png")}
          />
          <Text style={styles.personText}>person</Text>
        </View>
      </View>
      <Pressable
        style={styles.keluarPressable}
        onPress={() => navigation.navigate("Login")}
      >
        <Text style={styles.keluarText}>Keluar</Text>
      </Pressable>
      <Text style={styles.tentangKamiText}>Tentang Kami</Text>
      <Text style={styles.pengaturanText}>Pengaturan</Text>
      <Text style={styles.editProfilText}>Edit Profil</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  ml60: {
    marginLeft: 60,
  },
  icon: {
    width: "100%",
    height: "100%",
    flexShrink: 0,
  },
  homeIconSilhouette1Pressable: {
    position: "relative",
    width: 30,
    height: 30,
  },
  localGroceryStoreText: {
    fontSize: 30,
    fontFamily: "Material Icons",
    color: "#00ab66",
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 30,
    height: 30,
  },
  localGroceryStorePressable: {
    position: "relative",
  },
  inboxText: {
    fontSize: 30,
    fontFamily: "Material Icons",
    color: "#00ab66",
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 30,
    height: 30,
  },
  inboxPressable: {
    position: "relative",
  },
  user1Icon: {
    position: "relative",
    width: 30,
    height: 30,
    flexShrink: 0,
  },
  frameView: {
    position: "absolute",
    top: 590,
    left: 0,
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: -4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 360,
    flexDirection: "row",
    paddingHorizontal: 22,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  frameView1: {
    position: "absolute",
    top: 0,
    left: 0,
    borderBottomRightRadius: 25,
    borderBottomLeftRadius: 25,
    backgroundColor: "rgba(0, 171, 102, 0.5)",
    width: 360,
    height: 109,
    overflow: "hidden",
  },
  money1Icon: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 20,
    height: 20,
  },
  rp50000Text: {
    position: "absolute",
    top: 1,
    left: 23,
    fontSize: 14,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#00ab66",
    textAlign: "left",
  },
  groupView: {
    position: "absolute",
    top: 53,
    left: 90,
    width: 96,
    height: 20,
  },
  ilyasRixqiMartuti: {
    position: "absolute",
    top: 34,
    left: 90,
    fontSize: 16,
    fontWeight: "700",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  ellipseIcon: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 65,
    height: 65,
  },
  personText: {
    position: "absolute",
    top: 6,
    left: 8,
    fontSize: 50,
    fontFamily: "Material Icons",
    color: "#00ab66",
    textAlign: "center",
  },
  groupView1: {
    position: "absolute",
    top: 22,
    left: 14,
    width: 65,
    height: 65,
  },
  groupView2: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 360,
    height: 109,
  },
  keluarText: {
    fontSize: 14,
    fontWeight: "600",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  keluarPressable: {
    position: "absolute",
    left: 14,
    top: 237,
  },
  tentangKamiText: {
    position: "absolute",
    top: 204,
    left: 14,
    fontSize: 14,
    fontWeight: "600",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  pengaturanText: {
    position: "absolute",
    top: 171,
    left: 14,
    fontSize: 14,
    fontWeight: "600",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  editProfilText: {
    position: "absolute",
    top: 138,
    left: 14,
    fontSize: 14,
    fontWeight: "600",
    fontFamily: "Inter",
    color: "#000",
    textAlign: "left",
  },
  profilView: {
    position: "relative",
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 640,
    overflow: "hidden",
  },
});

export default Profil;
